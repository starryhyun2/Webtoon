package vo;

public class WebtoonCommentsVO {

	int comments_idx,step, depth, episode_idx; 
	String content, id;
	public int getComments_idx() {
		return comments_idx;
	}
	public void setComments_idx(int comments_idx) {
		this.comments_idx = comments_idx;
	}
	public int getStep() {
		return step;
	}
	public void setStep(int step) {
		this.step = step;
	}
	public int getDepth() {
		return depth;
	}
	public void setDepth(int depth) {
		this.depth = depth;
	}
	public int getEpisode_idx() {
		return episode_idx;
	}
	public void setEpisode_idx(int episode_idx) {
		this.episode_idx = episode_idx;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	
}
