package dao;

import java.util.HashMap;
import java.util.List;

import org.apache.ibatis.session.SqlSession;

import vo.BookmarkVO;
import vo.WebtoonVO;

public class BookmarkDAO {

	SqlSession sqlSession;
	public void setSqlSession(SqlSession sqlSession) {
		this.sqlSession = sqlSession;
	}
	
	//버튼 클릭시 북마크 DB에 동일한 값이 존재하는지 체크하는 메소드
	public BookmarkVO select(BookmarkVO vo) {
		BookmarkVO res = sqlSession.selectOne("bm.check_bookmark", vo);
		return res;
	}
	
	//동일한 값이 없다면 DB에 추가하는 메소드
	public int insert(BookmarkVO vo) {
		int res = sqlSession.insert("bm.add_bookmark", vo);
		return res;
	}
	
	//동일한 값이 있다면 DB에 삭제하는 메소드
	public void del(BookmarkVO vo) {
		sqlSession.delete("bm.del_bookmark", vo);
		return;
	}
	
	//내 북마크 리스트
	public List<BookmarkVO> selectList(String id) {
		List<BookmarkVO> res = sqlSession.selectList("bm.list_bookmark", id);
		return res;
	}
	
	public String count(String id){
		String res = sqlSession.selectOne("bm.count_bookmark",id);
		return res;
	}
	
	public List<WebtoonVO> selectGenre(String genre) {
		List<WebtoonVO> res = sqlSession.selectList("bm.select_genre", genre);
		return res;
	}
	
	
}
