package vo;

public class ScoreVO {
	int episode_idx, score;
	String id;
	public int getEpisode_idx() {
		return episode_idx;
	}
	public void setEpisode_idx(int episode_idx) {
		this.episode_idx = episode_idx;
	}
	public int getScore() {
		return score;
	}
	public void setScore(int score) {
		this.score = score;
	}
	public String getId() {
		return id;
	}
	public void setId(String id) {
		this.id = id;
	}
	
}
